<x-layout> 
    <h1> Hello from email page. </h1>
</x-layout>