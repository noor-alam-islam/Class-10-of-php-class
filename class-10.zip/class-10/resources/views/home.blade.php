<x-layout> 
    <h1> Hello from Home page. </h1>
</x-layout>