<x-layout> 
    <h1> Hello from contact page. </h1>
</x-layout>