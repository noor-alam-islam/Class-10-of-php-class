<x-layout> 
    <h1> Hello from about page. </h1>
</x-layout>